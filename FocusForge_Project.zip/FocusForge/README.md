# FocusForge
A minimalist dark-themed Pomodoro timer with AI productivity check-ins.